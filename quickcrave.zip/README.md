# QuickCrave — ordering website + backend

A complete online food ordering shop: storefront, accounts, cart, checkout with
cash on delivery / GCash / Maya, order tracking, favorites, addresses and an
owner console for managing orders.

Everything that runs in the browser lives in **one file** — `index.html` — with
the CSS and JavaScript inside it. There is no `style.css`, no build step and no
npm install needed to look at the site. The backend is a small
Node.js + Express + SQLite API in `backend/`.

```
quickcrave/
├── index.html          the whole storefront (inline CSS + inline JS)
├── README.md           this file
├── .gitignore
└── backend/
    ├── server.js       API + serves index.html
    ├── db.js           SQLite schema and the menu seed
    ├── auth.js         password hashing, login tokens, admin key
    ├── validate.js     request validation
    ├── routes/         auth, products, orders, favorites, addresses, admin
    ├── package.json
    └── .env.example
```

---

## 1. Quick look (no server needed)

Open `index.html` in a browser — or double-click it. Every page works: menu,
cart, checkout, order tracking, favorites, addresses, help, sign up and sign in.

Because there is no server in this mode, the site shows a **Demo mode** banner
and keeps accounts, orders, favorites and addresses in that browser's local
storage. That is for looking around and showing the shop to people — it is not a
backend. Move to step 2 for the real thing.

## 2. Run the full shop locally

You need [Node.js](https://nodejs.org) 20 or newer.

```bash
cd backend
cp .env.example .env      # then open .env and set JWT_SECRET and ADMIN_KEY
npm install               # or: pnpm install
node server.js
```

Open <http://localhost:3000>. The Demo banner disappears, and now:

- accounts are real (passwords are hashed, never stored in plain text)
- orders are priced and saved on the server, in `backend/quickcrave.db`
- favorites and addresses belong to the signed-in customer
- the owner console at `#/admin` is unlocked with your `ADMIN_KEY`

Change the port with `PORT=8080 node server.js`.

## 3. Put it on GitHub

From inside this `quickcrave` folder:

```bash
git init
git add .
git commit -m "QuickCrave ordering website and API"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

`.gitignore` already keeps `node_modules/`, the `.env` file and the `.db`
database out of the repository. Never commit `.env`.

## 4. Deploy it

### Option A — one service runs everything (simplest)

Recommended: push the `quickcrave` folder as its own repository, so the repo root
contains `index.html` and `backend/`. Then on
[Render](https://render.com) or [Railway](https://railway.app):

| Setting | Value |
| --- | --- |
| Build command | `cd backend && npm install` |
| Start command | `node backend/server.js` |
| Environment | `JWT_SECRET`, `ADMIN_KEY`, `CORS_ORIGIN=https://your-domain.com` |
| Disk (Render) | mount at `/data`, then set `DB_FILE=/data/quickcrave.db` |

`server.js` serves both the API and `index.html` on the same address, so this is
the fewest moving parts. Add the persistent disk, otherwise the database is
reset on every deploy.

### Option B — static storefront + separate API (fastest page loads)

1. Host `index.html` anywhere static (Netlify, Vercel, GitHub Pages, cPanel).
2. Deploy the API as in Option A, but set `CORS_ORIGIN` to your storefront
   address (comma separated for several).
3. In `index.html`, set `API_BASE` near the top of the script to your API
   address, for example `API_BASE: "https://quickcrave-api.onrender.com"`.

## 5. API reference

All requests and responses are JSON. Send the login token as
`Authorization: Bearer <token>`. Owner routes need an `x-admin-key` header.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Is the API up (used by the storefront to detect live mode) |
| GET | `/api/products` | The menu |
| POST | `/api/auth/register` | `{ name, email, password }` → `{ token, user }` |
| POST | `/api/auth/login` | `{ email, password }` → `{ token, user }` |
| GET | `/api/auth/me` | The signed-in customer |
| GET | `/api/orders` | Your orders, newest first |
| POST | `/api/orders` | `{ items:[{ productId, quantity }], paymentMethod, paymentRef, address }` |
| GET | `/api/orders/:code` | One order |
| POST | `/api/orders/:code/cancel` | Cancel while pending or confirmed |
| POST | `/api/orders/:code/payment` | Add or correct a GCash/Maya reference |
| GET | `/api/favorites` | Saved item ids |
| POST | `/api/favorites` | `{ productId }` |
| DELETE | `/api/favorites/:productId` | Remove |
| GET / POST | `/api/addresses` | List / add a delivery address |
| PATCH / DELETE | `/api/addresses/:id` | Edit / remove |
| POST | `/api/addresses/:id/default` | Make it the default |
| GET | `/api/admin/orders?status=` | All orders (owner) |
| PATCH | `/api/admin/orders/:code/status` | `{ status }` (owner) |

Order numbers look like `QC-20261006-0007`. Statuses move
`pending → confirmed → preparing → out_for_delivery → delivered`, and an order can
also be `cancelled`.

Prices are always recalculated on the server from the products table, so a
tampered browser cannot change what an order costs.

## 6. Making it yours

| What | Where |
| --- | --- |
| Menu items, prices, descriptions | `backend/db.js` (`SEED_PRODUCTS`) **and** the `PRODUCTS` list in `index.html` — keep them identical |
| Delivery fee (currently ₱39) | `CONFIG.DELIVERY_FEE` in `index.html` and `DELIVERY_FEE` in `backend/db.js` |
| Shop name, phone, email, hours | `CONFIG` at the top of the script in `index.html` |
| Where GCash/Maya payments go | `CONFIG.SUPPORT_PHONE` in `index.html` — put your real receiving number there |
| Colours, spacing, fonts | the `:root` tokens in the `<style>` block of `index.html` |
| Food photos | the `image(...)` Unsplash links in `PRODUCTS`, or replace them with your own image files |

The seed updates existing rows by id, so changing a price in `backend/db.js` and
restarting the server is enough.

## 7. Before you take real orders

- [ ] Set a long random `JWT_SECRET` and your own `ADMIN_KEY`, and keep `.env` out of Git.
- [ ] Set `CORS_ORIGIN` to your real domain (not `*`).
- [ ] Put your real GCash/Maya number in `CONFIG.SUPPORT_PHONE`.
- [ ] Add a persistent disk for the database, or move to a managed database.
- [ ] Replace the sample Unsplash food photos with your own.
- [ ] Add an `og:image` (1200×630) so links preview nicely when shared.
- [ ] Set up backups of `quickcrave.db`, and HTTPS (hosts do this for free).

### A note on admin protection

The owner console (`#/admin`) is only truly protected when the backend is
running, because the admin key is checked on the server. In demo mode the check
happens in the browser only, which is fine for a preview but is not security.

### Adding card payments later

Checkout already collects the payment method and reference number, so the clean
upgrade path is a payment gateway (PayMongo, Stripe) in `POST /api/orders`:
create the payment intent before saving the order, and confirm it on a webhook.
That needs the gateway account and secret keys, which only you can create.
